﻿namespace CRUD_Application
{


    partial class AppData
    {
    }
}

namespace CRUD_Application.AppDataTableAdapters {
    
    
    public partial class PhoneBooksTableAdapter {
    }
}
